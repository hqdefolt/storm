import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Contains the arguments with which the app was started.
final appArgumentsProvider = Provider((ref) => <String>[]);
